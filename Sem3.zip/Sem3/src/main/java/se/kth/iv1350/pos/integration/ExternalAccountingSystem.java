package se.kth.iv1350.pos.integration;

import se.kth.iv1350.pos.model.Sale;

public class ExternalAccountingSystem {
 
    public ExternalAccountingSystem() {
    
    }
    /**
     *  This method updates the accounting system after the sale is concluded
     * @param sale Has the information about the entire sale
     */
    public void updateExternalAccountingSystem(Sale sale) {
   
    }
    
}