package se.kth.iv1350.pos.integration;

import se.kth.iv1350.pos.model.Receipt;



public class Printer {
    
    Receipt receipt = new Receipt();
    
    /**
     *  An instance of the class printer;
     * 
     */
    public Printer () {
      
    
    }
    
    /**
     * This method is responsible for printing the receipt
     * @param receipt gold all the information about the entire sale.
     */
    public void printReceipt (Receipt receipt) {
    
    
    }
    
}
